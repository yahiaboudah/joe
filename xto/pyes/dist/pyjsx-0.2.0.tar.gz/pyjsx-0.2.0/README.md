# PYJSX

Send requests to python, call python functions from within extendscript easily.